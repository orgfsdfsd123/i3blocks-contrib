# docker

Show the number of running `Docker` containers and latest created container IP address.

![](docker.jpg)

# Dependencies

*docker* 

# Config

```
[docker]
command=$SCRIPT_DIR/docker
color=#0db7ed
interval=10
LABEL=🐳 
```
