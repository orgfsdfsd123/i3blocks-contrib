# memory

Show memory usage. Accepts instance "mem" or "swap".

![](memory.png)

# Config

```
[memory]
command=$SCRIPT_DIR/memory
label=MEM
interval=30

#[memory]
#command=$SCRIPT_DIR/memory
#label=SWAP
#instance=swap
#interval=30
```
